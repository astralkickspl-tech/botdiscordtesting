require('dotenv').config();
const { 
    Client, 
    GatewayIntentBits, 
    REST, 
    Routes, 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionFlagsBits,
    ChannelType 
} = require('discord.js');
const Parser = require('rss-parser');
const parser = new Parser();

// Globalne zmienne
let lastVideoId = null;
let lastStickyMessageId = null; // Zapamiętanie i usuwanie poprzedniej wiadomości Sticky
const ticketData = new Map();

// 1. Inicjalizacja bota Discord
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers
    ]
});

// 2. Konfiguracja stałych
const CONFIG = {
    welcomeChannelId: '1531682885596086364',
    feedbackChannelId: '1532849308787937441', // Kanał na vouche
    freeConfigChannelId: '1531673799907606708', // Kanał dla Free Config Access
    violenceRoleId: '1531756097759740085',
    staffRoleId: '1531825434357006366',
    
    // --- KONFIGURACJA YOUTUBE ---
    ytChannelId: 'UCZNNGdxj_Kyeg3atUN87_UQ', 
    ytDiscordChannelId: '1531672168679870598', 
    
    arrowEmoji: '<a:redarrow:1534325808196227254>',
    embedColor: 0x8B0000
};

// 3. Rejestracja komend Slash
const commands = [
    new SlashCommandBuilder()
        .setName('paypal')
        .setDescription('Wysyła instrukcję płatności PayPal Family & Friends'),
    new SlashCommandBuilder()
        .setName('setup-tickets')
        .setDescription('Wysyła panel tworzenia ticketów na obecny kanał')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
].map(command => command.toJSON());

// Funkcja sprawdzająca nowe filmy na YouTube
async function checkYouTube() {
    if (!CONFIG.ytChannelId) return;

    try {
        const feed = await parser.parseURL(`https://www.youtube.com/feeds/videos.xml?channel_id=${CONFIG.ytChannelId}`);
        
        if (feed && feed.items.length > 0) {
            const latestVideo = feed.items[0];
            
            if (!lastVideoId) {
                lastVideoId = latestVideo.id;
                return;
            }

            if (latestVideo.id !== lastVideoId) {
                lastVideoId = latestVideo.id;

                const channel = client.channels.cache.get(CONFIG.ytDiscordChannelId);
                if (channel) {
                    await channel.send({
                        content: `@everyone **Nowy film na YouTube!** 🚀\n\n**${latestVideo.title}**\n${latestVideo.link}`
                    });
                }
            }
        }
    } catch (error) {
        console.error('❌ Błąd podczas sprawdzania YouTube RSS:', error.message);
    }
}

// Funkcja Sticky Message (Automessage co 5 minut)
async function sendStickyMessage() {
    if (!CONFIG.freeConfigChannelId) return;

    const channel = client.channels.cache.get(CONFIG.freeConfigChannelId);
    if (!channel) return;

    try {
        // Usuwanie poprzedniej wiadomości, aby usunąć powiadomienia/spam i wrzucić nową na sam dół
        if (lastStickyMessageId) {
            const oldMsg = await channel.messages.fetch(lastStickyMessageId).catch(() => null);
            if (oldMsg) {
                await oldMsg.delete().catch(() => {});
            }
        }

        // Embed z poprawionym tekstem
        const stickyEmbed = new EmbedBuilder()
            .setDescription(
                `\`\`\`🔓 ‧ Violènce  ⨯  FREE CONFIGS\`\`\`\n\n` +
                `To unlock free configs access:\n` +
                `1. Subscribe to **Violènce YouTube Channel**\n` +
                `2. **Like any of Violènce Video** on YouTube\n` +
                `3. Sent **Proof in this channel**, and **patiently wait for staff** members to give you role.\n\n` +
                `**__NEVER PING OWNER - BAN__**`
            )
            .setColor(CONFIG.embedColor);

        const newMsg = await channel.send({ embeds: [stickyEmbed] });
        lastStickyMessageId = newMsg.id;
    } catch (error) {
        console.error('❌ Błąd podczas wysyłania Sticky Message:', error.message);
    }
}

// 4. Start bota
client.once('ready', async () => {
    console.log(`✅ Bot zalogowany jako: ${client.user.tag}`);

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

    try {
        console.log('🔄 Rejestrowanie komend slash...');
        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands }
        );
        console.log('✅ Komendy slash zarejestrowane!');
    } catch (error) {
        console.error('❌ Błąd rejestracji komend:', error);
    }

    // Sprawdzanie YouTube
    checkYouTube();
    setInterval(checkYouTube, 3 * 60 * 1000);

    // Wysyłanie sticky message co 5 minut
    sendStickyMessage();
    setInterval(sendStickyMessage, 5 * 60 * 1000);
});

// 5. Obsługa wejścia nowego użytkownika (WELCOME EMBED)
client.on('guildMemberAdd', async member => {
    const channel = member.guild.channels.cache.get(CONFIG.welcomeChannelId);
    if (!channel) return;

    const memberCount = member.guild.memberCount;

    const welcomeEmbed = new EmbedBuilder()
        .setDescription(
            `\`\`\`👋 ‧ Violènce  ⨯  Welcome\`\`\`\n` +
            `${CONFIG.arrowEmoji} Welcome ${member} to **Violènce**\n` +
            `${CONFIG.arrowEmoji} You are our **__${memberCount}__** member.\n` +
            `${CONFIG.arrowEmoji} Check out our **[sale on violence.win !](https://violence.win)**`
        )
        .setColor(CONFIG.embedColor);

    await channel.send({ embeds: [welcomeEmbed] });
});

// 6. Główna obsługa interakcji
client.on('interactionCreate', async interaction => {

    if (interaction.isChatInputCommand()) {
        const { commandName } = interaction;

        if (commandName === 'paypal') {
            const paypalEmbed = new EmbedBuilder()
                .setAuthor({ name: 'Violence Service - Guide how to buy from us by PAYPAL Family & Friends' })
                .setTitle('Payment PayPal x Violence Service')
                .setColor(CONFIG.embedColor)
                .setDescription(
                    `${CONFIG.arrowEmoji} **1. Click on paypal page next, Sent money**\n\n` +
                    `${CONFIG.arrowEmoji} **2. Type this exact e-mail:** artkendi72@gmail.com\n\n` +
                    `${CONFIG.arrowEmoji} **3. Sent money by: $ / Euro / PLN**\n\n` +
                    `${CONFIG.arrowEmoji} **4. IMPORTANT! Select option "Family & Friends"**\n\n` +
                    `${CONFIG.arrowEmoji} **5. Sent screenshot of money being sent on this channel**\n\n` +
                    `${CONFIG.arrowEmoji} **6. Leave a +rep (PRODUCT NAME) on this channel**\n` +
                    `<#${CONFIG.feedbackChannelId}>`
                )
                .addFields({
                    name: '\u200B',
                    value: `After you done everything correctly wait for <@&${CONFIG.staffRoleId}> <@&${CONFIG.violenceRoleId}> patiently to give your desired product.`
                })
                .setFooter({ text: 'if you send money different than "Family and Friends" option your money WILL BE NOT refunded.' });

            return await interaction.reply({ embeds: [paypalEmbed] });
        }

        if (commandName === 'setup-tickets') {
            const ticketEmbed = new EmbedBuilder()
                .setDescription(
                    `\`\`\`🎫 ‧ Violènce  ⨯  TICKETS\`\`\`\n` +
                    `${CONFIG.arrowEmoji} **Select correct reason before opening ticket, it helps staff a lot, Thank you for choosing us - Violènce Team**\n\n` +
                    `${CONFIG.arrowEmoji} 🛒 **Purchase - Want to purchase with different payment method?**\n` +
                    `${CONFIG.arrowEmoji} 🧾 **Payment Proof - Purchased, but not received any product?**\n` +
                    `${CONFIG.arrowEmoji} 🎥 **Media Program - Get free promo and earn real money at the same time!**`
                )
                .setColor(CONFIG.embedColor);

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('ticket_select')
                    .setPlaceholder('Select a category...')
                    .addOptions([
                        {
                            label: 'Purchase',
                            description: 'Want to purchase with different payment method?',
                            value: 'purchase',
                            emoji: '🛒'
                        },
                        {
                            label: 'Payment Proof',
                            description: 'Purchased, but not received any product?',
                            value: 'payment_proof',
                            emoji: '📜'
                        },
                        {
                            label: 'Media Program',
                            description: 'Get Free promo and Earn real money at the same time!',
                            value: 'media_program',
                            emoji: '▶️'
                        }
                    ])
            );

            await interaction.channel.send({ embeds: [ticketEmbed], components: [selectMenu] });
            return await interaction.reply({ content: '✅ Panel ticketów został wysłany!', ephemeral: true });
        }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
        const selectedOption = interaction.values[0];

        if (selectedOption === 'payment_proof') {
            const modal = new ModalBuilder()
                .setCustomId('modal_payment_proof')
                .setTitle('Payment Proof Verification');

            const invoiceInput = new TextInputBuilder()
                .setCustomId('invoice_id_input')
                .setLabel('Invoice ID')
                .setPlaceholder('Invoice #ef764a35db1af-0000016264940')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const detailsInput = new TextInputBuilder()
                .setCustomId('additional_info_input')
                .setLabel('Sent us payment proof from website')
                .setPlaceholder('Additional details, screenshots or payment notes (Optional)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false);

            modal.addComponents(
                new ActionRowBuilder().addComponents(invoiceInput),
                new ActionRowBuilder().addComponents(detailsInput)
            );

            return await interaction.showModal(modal);
        }

        if (selectedOption === 'purchase') {
            const modal = new ModalBuilder()
                .setCustomId('modal_purchase')
                .setTitle('Purchase Details');

            const productInput = new TextInputBuilder()
                .setCustomId('product_name_input')
                .setLabel('Product name')
                .setPlaceholder('example - MS Semi-rage config')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const durationInput = new TextInputBuilder()
                .setCustomId('duration_input')
                .setLabel('Duration')
                .setPlaceholder('example - 31d, 1 year, Lifetime, N/A')
                .setStyle(TextInputStyle.Short)
                .setRequired(false);

            const paymentMethodInput = new TextInputBuilder()
                .setCustomId('payment_method_input')
                .setLabel('Payment Method')
                .setPlaceholder('example - paypal, TF2 Keys, PSC, Steam')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(productInput),
                new ActionRowBuilder().addComponents(durationInput),
                new ActionRowBuilder().addComponents(paymentMethodInput)
            );

            return await interaction.showModal(modal);
        }

        if (selectedOption === 'media_program') {
            const modal = new ModalBuilder()
                .setCustomId('modal_media')
                .setTitle('Media Program Application');

            const socialsInput = new TextInputBuilder()
                .setCustomId('socials_input')
                .setLabel('Your Social media channels (Links)')
                .setPlaceholder('example: Tiktok, YouTube, Twitch, Kick')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const contentTimeInput = new TextInputBuilder()
                .setCustomId('content_time_input')
                .setLabel('For how long have you been making content?')
                .setPlaceholder('example: 1 Year, 1 Month, Newcomer')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const viewsCountInput = new TextInputBuilder()
                .setCustomId('views_count_input')
                .setLabel('Average viewers / views count')
                .setPlaceholder('example: 15k TikTok / 2k YouTube | Twitch / Kick 100 average viewers')
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(socialsInput),
                new ActionRowBuilder().addComponents(contentTimeInput),
                new ActionRowBuilder().addComponents(viewsCountInput)
            );

            return await interaction.showModal(modal);
        }
    }

    if (interaction.isModalSubmit()) {
        const guild = interaction.guild;
        const user = interaction.user;
        const customId = interaction.customId;

        let ticketType = '';
        let modalFields = [];
        let purchaseDetails = null;

        if (customId === 'modal_payment_proof') {
            ticketType = 'payment-proof';
            const invoiceId = interaction.fields.getTextInputValue('invoice_id_input');
            const additionalInfo = interaction.fields.getTextInputValue('additional_info_input') || 'None';

            modalFields = [
                { name: '🧾 Invoice ID', value: invoiceId },
                { name: '📝 Additional Details', value: additionalInfo }
            ];

            purchaseDetails = {
                type: 'payment_proof',
                user: user,
                invoiceId: invoiceId
            };
        } else if (customId === 'modal_purchase') {
            ticketType = 'purchase';
            const product = interaction.fields.getTextInputValue('product_name_input');
            const duration = interaction.fields.getTextInputValue('duration_input') || '';
            const payment = interaction.fields.getTextInputValue('payment_method_input');

            modalFields = [
                { name: '🛒 Product Name', value: product },
                { name: '⏳ Duration', value: duration || 'N/A' },
                { name: '💳 Payment Method', value: payment }
            ];

            purchaseDetails = {
                type: 'purchase',
                user: user,
                product: product,
                duration: duration,
                payment: payment
            };
        } else if (customId === 'modal_media') {
            ticketType = 'media';
            modalFields = [
                { name: '🔗 Social Media Channels', value: interaction.fields.getTextInputValue('socials_input') },
                { name: '⏱️ Content Duration', value: interaction.fields.getTextInputValue('content_time_input') },
                { name: '📊 Average Viewers/Views', value: interaction.fields.getTextInputValue('views_count_input') }
            ];
        }

        const channelName = `${ticketType}-${user.username.toLowerCase()}`;
        const existingChannel = guild.channels.cache.find(c => c.name === channelName);
        if (existingChannel) {
            return await interaction.reply({ 
                content: `⚠️ Masz już otwarty ticket tego typu: ${existingChannel}`, 
                ephemeral: true 
            });
        }

        await interaction.deferReply({ ephemeral: true });

        const ticketChannel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles]
                },
                {
                    id: CONFIG.staffRoleId,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles]
                }
            ]
        });

        if (purchaseDetails) {
            ticketData.set(ticketChannel.id, purchaseDetails);
        }

        const welcomeEmbed = new EmbedBuilder()
            .setTitle(`Ticket: ${ticketType.toUpperCase()}`)
            .setDescription(
                `Welcome ${user} Please wait patiently for <@&${CONFIG.staffRoleId}> to respond your ticket, remember everyone have their own life, don't rush them please!\n\n` +
                `Thank you for choosing us Boss!\n` +
                `We wish you all the best - **𝚅𝚒𝚘𝚕𝚎𝚗𝚌𝚎 Team**`
            )
            .addFields(modalFields)
            .setColor(CONFIG.embedColor)
            .setTimestamp();

        const closeButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('Close Ticket')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒')
        );

        await ticketChannel.send({ 
            content: `${user} | <@&${CONFIG.staffRoleId}>`, 
            embeds: [welcomeEmbed], 
            components: [closeButton] 
        });

        await interaction.editReply({ 
            content: `✅ Twój ticket został pomyślnie utworzony: ${ticketChannel}` 
        });
    }

    // --- ZAMYKANIE TICKETA & AUTO VOUCH ---
    if (interaction.isButton() && interaction.customId === 'close_ticket') {
        await interaction.reply({ content: '🔒 Zamknięcie ticketa nastąpi za 5 sekund...' });
        
        const channelId = interaction.channel.id;
        const staffMember = interaction.user;

        if (ticketData.has(channelId)) {
            const data = ticketData.get(channelId);
            const feedbackChannel = interaction.guild.channels.cache.get(CONFIG.feedbackChannelId);

            if (feedbackChannel) {
                try {
                    let vouchContent = '';

                    if (data.type === 'purchase') {
                        const durationText = data.duration ? `${data.duration} ` : '';
                        vouchContent = `+rep <@${staffMember.id}> ${data.product} ${durationText}x1 [${data.payment}]`;
                    } else if (data.type === 'payment_proof') {
                        vouchContent = `+rep <@${staffMember.id}> ${data.invoiceId} [website]`;
                    }

                    if (vouchContent) {
                        const webhook = await feedbackChannel.createWebhook({
                            name: data.user.displayName || data.user.username,
                            avatar: data.user.displayAvatarURL({ dynamic: true })
                        });

                        await webhook.send({ content: vouchContent });
                        await webhook.delete();
                    }
                } catch (err) {
                    console.error('❌ Błąd podczas wysyłania auto-vouche\'a:', err);
                }
            }
            ticketData.delete(channelId);
        }

        setTimeout(async () => {
            try {
                await interaction.channel.delete();
            } catch (err) {
                console.error('Błąd podczas usuwania kanału:', err);
            }
        }, 5000);
    }
});

// 7. Logowanie bota
client.login(process.env.DISCORD_TOKEN);